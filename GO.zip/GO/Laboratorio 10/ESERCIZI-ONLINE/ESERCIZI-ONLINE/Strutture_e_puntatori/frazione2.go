package main

import "fmt"
import "os"
import "strconv"

func main() {

  numeratore, _ := strconv.Atoi(os.Args[1])
	denominatore, _ := strconv.Atoi(os.Args[2])

	frazione := NuovaFrazione(numeratore, denominatore)
  Riduci(frazione)
	fmt.Println(String(*frazione))
}

type Frazione struct {
	numeratore, denominatore int
}

func Riduci(f *Frazione) {

  mcd := 1
	for i := 1; i <= f.numeratore && i <= f.denominatore; i++ {
		if f.numeratore%i == 0 && f.denominatore%i == 0 {
			mcd = i
		}
	}
	f.numeratore /= mcd
	f.denominatore /= mcd

}

func NuovaFrazione(numeratore, denominatore int) *Frazione {
	return &Frazione{numeratore, denominatore}
}

func String(f Frazione) string {
	return fmt.Sprintf("%d/%d", f.numeratore, f.denominatore)
}
