package main

import "fmt"

type Contatto struct {
  cognome string
  nome string
  telefono string
  indirizzo Indirizzo
}

type Indirizzo struct {
  via string
  cap string
  citta string
  numeroCivico uint
}
 
type Rubrica []Contatto

func NuovaRubrica() Rubrica {
  return Rubrica{}
}

func InserisciContatto(rubrica Rubrica, cognome, nome string, via string, numeroCivico uint, cap, citta string, telefono string) Rubrica {
  for i := 0; i < len(rubrica); i++ {
    if rubrica[i].cognome == cognome && rubrica[i].nome == nome {
      return rubrica
    }
  }

  return append(rubrica, Contatto{cognome, nome, telefono, Indirizzo {via, cap, citta, numeroCivico}})
}

func EliminaContatto(rubrica Rubrica, cognome, nome string) Rubrica {
  for i, c := range rubrica {
    if c.nome == nome && c.cognome == cognome {
      rubrica = append(rubrica[:i], rubrica[i+1:]...)
    }
  }
  return rubrica
}

func StampaContatto(c Contatto) {

  fmt.Println(c.nome, c.cognome, ":", c.indirizzo.via, c.indirizzo.numeroCivico, ",", c.indirizzo.citta, ",", c.indirizzo.cap, "- Tel", c.telefono)

}

func StampaRubrica(rubrica Rubrica) {
  fmt.Println("Rubrica:")
  for _, c := range rubrica {
    StampaContatto(c)
  }
}

func AggiornaContatto(rubrica Rubrica, cognome, nome string, via string, numero uint, cap, citta string, telefono string) Rubrica {
  for i, c := range rubrica {
    if c.nome == nome && c.cognome == cognome {
      rubrica[i].indirizzo.via, rubrica[i].indirizzo.cap, rubrica[i].indirizzo.citta = via, cap, citta
      rubrica[i].telefono = telefono
      rubrica[i].indirizzo.numeroCivico = numero
    }
  }
  return rubrica
}


func main() {
  rubrica := NuovaRubrica()

	rubrica = InserisciContatto(rubrica, "Mario", "Rossi",
		"Via Festa del Perdono", 11, "20122", "Milano", "02503111")
	rubrica = InserisciContatto(rubrica, "Mario", "Rossi",
		"Via Festa del Perdono", 11, "", "", "")
	rubrica = InserisciContatto(rubrica, "Anna", "Rossi",
		"Via Festa del Perdono", 11, "20122", "Milano", "02503111")
	rubrica = InserisciContatto(rubrica, "Carlo", "Rossi",
		"Via Festa del Perdono", 11, "20122", "Milano", "02503111")

	StampaRubrica(rubrica)

	rubrica = EliminaContatto(rubrica, "Mario", "Rossi")
	rubrica = EliminaContatto(rubrica, "Carlo", "Verdi")

	StampaRubrica(rubrica)

	rubrica = AggiornaContatto(rubrica, "Anna", "Rossi", "Via S. Sofia", 25, "20122", "Milano", "")

	StampaRubrica(rubrica)

}
