package main

import "fmt"
import "bufio"
import "os"
import "strings"
import "strconv"

type Contatto struct {
  cognome string
  nome string
  telefono string
  indirizzo Indirizzo
}

type Indirizzo struct {
  via string
  cap string
  citta string
  numeroCivico uint64
}

type Rubrica []Contatto

func NuovaRubrica() Rubrica {
  return Rubrica{}
}

func InserisciContatto(rubrica Rubrica, cognome, nome string, via string, numeroCivico uint64, cap, citta string, telefono string) Rubrica {
  for i := 0; i < len(rubrica); i++ {
    if rubrica[i].cognome == cognome && rubrica[i].nome == nome {
      return rubrica
    }
  }

  return append(rubrica, Contatto{cognome, nome, telefono, Indirizzo {via, cap, citta, numeroCivico}})
}

func EliminaContatto(rubrica Rubrica, cognome, nome string) Rubrica {
  for i, c := range rubrica {
    if c.nome == nome && c.cognome == cognome {
      rubrica = append(rubrica[:i], rubrica[i+1:]...)
    }
  }
  return rubrica
}

func StampaContatto(c Contatto) {

  fmt.Println(c.nome, c.cognome, ":", c.indirizzo.via, c.indirizzo.numeroCivico, ",", c.indirizzo.citta, ",", c.indirizzo.cap, "- Tel", c.telefono)

}

func StampaRubrica(rubrica Rubrica) {
  fmt.Println("Rubrica:")
  for _, c := range rubrica {
    StampaContatto(c)
  }
}

func AggiornaContatto(rubrica Rubrica, cognome, nome string, via string, numero uint64, cap, citta string, telefono string) Rubrica {
  for i, c := range rubrica {
    if c.nome == nome && c.cognome == cognome {
      rubrica[i].indirizzo.via, rubrica[i].indirizzo.cap, rubrica[i].indirizzo.citta = via, cap, citta
      rubrica[i].telefono = telefono
      rubrica[i].indirizzo.numeroCivico = numero
    }
  }
  return rubrica
}

func LeggiTesto() (operazioni []string) {
  scanner := bufio.NewScanner(os.Stdin)


	for scanner.Scan() {
		riga := scanner.Text()
		if riga == "" {
			return
		}
    operazioni = append(operazioni, riga)
	}
  return
}

func main() {
  rubrica := NuovaRubrica()

  operazioni := LeggiTesto()

  var i int

  for i < len(operazioni) {
    riga := strings.Split(operazioni[i], ";")
    switch riga[0]{
    case "I":
      uint,_ := strconv.ParseUint(riga[4], 10, 64)
      rubrica = InserisciContatto(rubrica, riga[1], riga[2], riga[3], uint, riga[5], riga[6], riga[7])
    case "E":
      rubrica = EliminaContatto(rubrica, riga[1], riga[2])
    case "S":
      StampaRubrica(rubrica)
    case "A":
      uint,_ := strconv.ParseUint(riga[4], 10, 64)
      rubrica = AggiornaContatto(rubrica, riga[1], riga[2], riga[3], uint, riga[5], riga[6], riga[7])
    }
    i++
  }


}
