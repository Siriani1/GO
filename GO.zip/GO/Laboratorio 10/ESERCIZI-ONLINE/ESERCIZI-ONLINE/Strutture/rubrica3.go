package main

import "fmt"
import "bufio"
import "os"
import "strings"
import "strconv"

type Contatto struct {
  cognome string
  nome string
  telefono string
  indirizzo Indirizzo
}

type Indirizzo struct {
  via string
  cap string
  citta string
  numeroCivico uint64
}

type Rubrica map[string]Contatto

func NuovaRubrica() Rubrica {
  return make(Rubrica)
}

func InserisciContatto(rubrica Rubrica, cognome, nome string, via string, numeroCivico uint64, cap, citta string, telefono string) Rubrica {
  chiave := nome + cognome
  _, ok := rubrica[chiave]
  if ok {
    return rubrica
  }
  rubrica[chiave] = Contatto{cognome, nome, telefono, Indirizzo{via, cap, citta, numeroCivico}}
	return rubrica
}

func EliminaContatto(rubrica Rubrica, cognome, nome string) Rubrica {
  chiave := nome + cognome
  _, ok := rubrica[chiave]
  if ok {
    delete(rubrica, chiave)
  }
  return rubrica
}

func StampaContatto(c Contatto) {

  fmt.Println(c.nome, c.cognome, ":", c.indirizzo.via, c.indirizzo.numeroCivico, ",", c.indirizzo.citta, ",", c.indirizzo.cap, "- Tel", c.telefono)

}

func StampaRubrica(rubrica Rubrica) {
  fmt.Println("Rubrica:")
  for _, c := range rubrica {
    StampaContatto(c)
  }
}

func AggiornaContatto(rubrica Rubrica, cognome, nome string, via string, numero uint64, cap, citta string, telefono string) Rubrica {
  chiave := nome + cognome
  _, ok := rubrica[chiave]
  if ok {
    rubrica[chiave] = Contatto{cognome, nome, telefono, Indirizzo{via, cap, citta, numero}}
  }

  return rubrica
}

func LeggiTesto() (operazioni []string) {
  scanner := bufio.NewScanner(os.Stdin)


	for scanner.Scan() {
		riga := scanner.Text()
		if riga == "" {
			return
		}
    operazioni = append(operazioni, riga)
	}
  return
}

func main() {
  rubrica := NuovaRubrica()

  operazioni := LeggiTesto()

  var i int

  for i < len(operazioni) {
    riga := strings.Split(operazioni[i], ";")
    switch riga[0]{
    case "I":
      uint,_ := strconv.ParseUint(riga[4], 10, 64)
      rubrica = InserisciContatto(rubrica, riga[1], riga[2], riga[3], uint, riga[5], riga[6], riga[7])
    case "E":
      rubrica = EliminaContatto(rubrica, riga[1], riga[2])
    case "S":
      StampaRubrica(rubrica)
    case "A":
      uint,_ := strconv.ParseUint(riga[4], 10, 64)
      rubrica = AggiornaContatto(rubrica, riga[1], riga[2], riga[3], uint, riga[5], riga[6], riga[7])
    }
    i++
  }


}
