package main

import "fmt"
import "Triangolo"
import "strconv"
import "os"

func main() {
  lato1, _ := strconv.ParseFloat(os.Args[1], 64)
  lato2, _ := strconv.ParseFloat(os.Args[2], 64)
  lato3, _ := strconv.ParseFloat(os.Args[3], 64)

  t, err := Triangolo.NuovoTriangolo(lato1, lato2, lato3)
	if err != nil {
		fmt.Println(err)
		return
	}

  fmt.Println("Perimetro del triangolo:", Triangolo.Perimetro(t))
  fmt.Println("Area del triangolo:", Triangolo.Area(t, Triangolo.Perimetro(t)))
}
