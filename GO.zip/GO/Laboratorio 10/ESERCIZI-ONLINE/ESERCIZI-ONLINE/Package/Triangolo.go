package Triangolo

import "errors"
import "math"
import "fmt"

type Triangolo struct {
  Lato1, Lato2, Lato3 float64
}

func NuovoTriangolo(lato1, lato2, lato3 float64) (Triangolo, error) {
  if lato1+lato2 <= lato3 || lato1+lato3 <= lato2 || lato2+lato2 <= lato1 {
		return Triangolo{}, errors.New("impossibile creare un triangolo con le misure specificate")
	}

	return Triangolo{lato1, lato2, lato3}, nil
}

func Perimetro(t Triangolo) float64 {
  return t.Lato1 + t.Lato2 + t.Lato3
}

func Area(t Triangolo) float64 {
  p := (t.Lato1 + t.Lato2 + t.Lato3) / 2
  return math.Sqrt(p * (p - t.Lato1) * (p- t.Lato2) * (p - t.Lato3))
}

func String(t Triangolo) string {
	return fmt.Sprintf("Triangolo con lati %f, %f e %f\n", t.Lato1, t.Lato2, t.Lato3)
}
