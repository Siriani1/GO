package main

import "fmt"
import "os"
import "strconv"
import "Triangolo"
import "math/rand"
import "math"
import "time"

func GeneraTriangoli(n int) (tN []Triangolo.Triangolo) {
  rand.Seed(int64(time.Now().Nanosecond()))
  for i := 0; i < n; i++ {
    for j := 0; j < 3; j++ {
      l1 := rand.Float64() * 990 + 10
      l2 := rand.Float64() * 990 + 10
      l3 := rand.Float64() * 990 + 10

      r, err := Triangolo.NuovoTriangolo(l1,l2,l3)
      if err == nil {
        tN = append(tN, r)
      }
    }
  }

  return
}

func areaMaggiore(tN []Triangolo.Triangolo) (areaMaggiore int) {
  max := math.SmallestNonzeroFloat64
  for i := 0; i < len(tN); i++ {
    if max < Triangolo.Area(tN[i]) {
      max = Triangolo.Area(tN[i])
      areaMaggiore = i
    }
  }

  return
}

func PerimetroMinore(tN []Triangolo.Triangolo) (perimetroMinore int) {
  min := math.MaxFloat64
  for i := 0; i < len(tN); i++ {
    if min > Triangolo.Perimetro(tN[i]) {
      min = Triangolo.Perimetro(tN[i])
      perimetroMinore = i
    }
  }
  return
}

func main() {


  n, _ := strconv.Atoi(os.Args[1])
  t := GeneraTriangoli(n)

  areaMaggiore := areaMaggiore(t)
  string := Triangolo.String(t[areaMaggiore])
  fmt.Print("Triangolo con area maggiore = ", string)
  perimetroMinore := PerimetroMinore(t)
  string = Triangolo.String(t[perimetroMinore])
  fmt.Print("Triangolo con perimentro minore = ", string)
}
