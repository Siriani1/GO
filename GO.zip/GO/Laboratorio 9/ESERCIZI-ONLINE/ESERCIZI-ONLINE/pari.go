package main

import "fmt"
import "os"
import "strconv"
import "math"

func MinimoDispari(sl []int) (min int) {
  min = int(math.MaxInt64)
  for _, n := range sl {
    if n % 2 != 0 {
      if n < min {
        min = n
      }
    }
  }
  return
}

func main() {
  var numeri []int
  numeri = make([]int, len(os.Args)-1)

  for i,s := range os.Args[1:] {
    if n, err := strconv.Atoi(s); err == nil {
			numeri[i] += n
		}
  }

  min := MinimoDispari(numeri)

  for _,n := range numeri {
    if n % 2 == 0{
      if n > min {
        fmt.Print(n, " ")
      }
    }
  }

}
