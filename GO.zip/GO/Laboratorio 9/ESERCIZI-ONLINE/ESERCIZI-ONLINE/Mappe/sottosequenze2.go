package main

import "fmt"
import "os"

func LeggiSequenza() []string {
  sequenzaInput := os.Args[1:]
  return sequenzaInput
}

func Sottosequenza(sl []string) map[string]int {
  m := map[string]int{}
  for i := 0; i < len(sl); i ++ {
    for j := i + 1; j < len(sl); j++ {
      if sl[i] == sl[j] {
        sequenza := ""
        for k := i; k <= j; k++ {
          sequenza += sl[k]
        }
        if len(sequenza) > 2 {
          m[sequenza]++
        }
      }
    }
  }
  return m
}

func StampaSottosequenze(m map[string]int, lunghezzaMassima int) {
  for lunghezza := lunghezzaMassima; lunghezza >= 3; lunghezza-- {
    for valore, ripetizioni := range m {
      if len(valore) == lunghezza {
        fmt.Println(valore, "--> Occorrenze:", ripetizioni)
      }
    }
  }
}

func main() {
  StampaSottosequenze(Sottosequenza(LeggiSequenza()), len(os.Args[1:]))

}
