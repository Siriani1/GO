package main

import "fmt"
import "bufio"
import "os"
import "unicode"
import "strings"

func LeggiTesto() (testo string) {
  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
    if scanner.Text() != ""{
        riga := scanner.Text()
        testo += riga + "\n"
        if testo == "" {
            continue
        }
    }else{
      break
    }
	}
	return testo[:len(testo)-1]
}

func IsLetter(r rune) bool {
  if unicode.IsLetter(r) {
    return true
  }

  return false
}

func Occorrenze(s string) map[rune]int {
  m := map[rune]int{}
  for _, r := range s {
    if IsLetter(r){
      m[r]++
    }
  }

  return m
}

func main() {
  occorrenze := Occorrenze(LeggiTesto())

	fmt.Println("Occorrenze:")
	for k, v := range occorrenze {
		fmt.Printf("%c: %s\n", k, strings.Repeat("*", v))
	}
}
