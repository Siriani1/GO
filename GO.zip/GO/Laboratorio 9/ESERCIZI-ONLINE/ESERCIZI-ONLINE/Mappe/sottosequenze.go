package main

import "fmt"
import "os"
//import "strconv"

const SEPARATORE = ' '

func LeggiNumeri() []string {
  sequenzaInput := os.Args[1:]
  return sequenzaInput
}

func Sottosequenza(sl []string) (sottoSequenza []string) {
  for i := 0; i < len(sl); i++ {
    for j := i + 1; j < len(sl); j++ {
      if sl[i] == sl[j] {
        sequenza := ""
        for k := i; k <= j; k++ {
          sequenza += sl[k] + string(SEPARATORE)
        }
        sottoSequenza = append(sottoSequenza, sequenza)
      }
    }
  }

  return
}

func main() {
  sl := Sottosequenza(LeggiNumeri())

  for _, s := range sl {
    fmt.Println(s)
  }
}
