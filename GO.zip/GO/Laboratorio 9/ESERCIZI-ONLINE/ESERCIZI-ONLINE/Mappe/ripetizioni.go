package main

import "fmt"
import "os"
import "bufio"
import "unicode"

func LeggiTesto() (testo string) {
  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
    if scanner.Text() != ""{
        riga := scanner.Text()
        testo += riga + "\n"
        if testo == "" {
            continue
        }
    }else{
      break
    }
	}
	return testo[:len(testo)-1]
}

func SeparaParole(s string) (sl []string) {
  var parola string
  for _, c := range s {
    if unicode.IsSpace(c) {
      sl = append(sl, parola)
      parola = ""
    } else {
      parola += string(c)
    }
  }
  if !unicode.IsSpace(rune(s[len(s)-1])) {
    sl = append(sl, parola)
  }

  return
}

func ContaRipetizioni(sl []string) map[string]int {
  m := map[string]int{}
  for _,s := range sl {
      m[s]++
  }
  return m
}

func main() {
  m := ContaRipetizioni(SeparaParole(LeggiTesto()))
  fmt.Println(m)
  for p, n := range m {
    fmt.Println(p, ":", n)
  }
}
