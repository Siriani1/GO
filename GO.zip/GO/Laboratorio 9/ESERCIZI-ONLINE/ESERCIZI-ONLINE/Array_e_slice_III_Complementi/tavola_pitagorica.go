package main

import "fmt"
import "os"
import "strconv"

func LeggiNumero() (numero int) {
  for _,s := range os.Args[1:] {
    if n, err := strconv.Atoi(s); err == nil {
			numero = n
		}
  }
  return numero
}

func CreaTavolaPeriodica(n int) (tavola [][]int) {
  tavola = make([][]int, n)
  for i := 0; i < n; i ++ {
    tavola[i] = make([]int, n)
    for j := 0; j < n; j++ {
      tavola[i][j] = (i + 1) * (j + 1)
    }
  }

  return
}

func StampaTavolaPitagorica(s [][]int) {
  for i := range s {
    for j := range s {
      fmt.Printf("%4d ", s[i][j])
    }
    fmt.Println()
  }
}

func main() {
  StampaTavolaPitagorica(CreaTavolaPeriodica(LeggiNumero()))
}
