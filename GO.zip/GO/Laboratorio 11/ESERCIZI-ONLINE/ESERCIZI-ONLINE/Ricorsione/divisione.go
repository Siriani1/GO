package main

import "fmt"
import "os"
import "strconv"

func main() {
  n1,_ := strconv.Atoi(os.Args[1])
  n2,_ := strconv.Atoi(os.Args[2])
  q, r := Dividi(n1,n2)
  fmt.Printf("Quoziente = %d, resto = %d ", q, r)
}

func Dividi(dividendo, divisore int) (quoziente, resto int) {
	if dividendo < divisore {
		return 0, dividendo
	} else {
		quoziente, resto = Dividi(dividendo-divisore, divisore)
		return quoziente + 1, resto
	}
}
