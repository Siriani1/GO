package main

import "fmt"

func main() {
  var string string
  fmt.Println("inserisci stringa")
  fmt.Scan(&string)

  fmt.Printf("Stringa invertita:\n%s", InvertiStringa(string))
}

func InvertiStringa(s string) string {
  if len(s) == 0 {
    return ""
  } else {
    return string(s[len(s)-1]) + InvertiStringa(s[:len(s)-1])
  }
}
