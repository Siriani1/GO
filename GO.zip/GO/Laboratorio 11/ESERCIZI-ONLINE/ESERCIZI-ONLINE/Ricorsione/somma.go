package main

import "fmt"
import "os"
import "strconv"

func LeggiNumeri() (numeri []int) {
  for _,s := range os.Args[1:] {
    if n, err := strconv.Atoi(s); err == nil {
			numeri = append(numeri, n)
		}
  }
  return numeri
}


func Somma(sl []int) int {
  if len(sl) == 0 {
    return 0
  } else {
    return sl[0] + Somma(sl[1:])
  }
}

func main() {
  fmt.Println("Somma", Somma(LeggiNumeri()))
}
