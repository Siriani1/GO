package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	LeggiEStampa(scanner)
}

func LeggiEStampa(scanner *bufio.Scanner) {

	if scanner.Scan() {
		s := scanner.Text()
		fmt.Println(InvertiStringa(s))
		LeggiEStampa(scanner)
	}

}

func InvertiStringa(s string) string {
  if len(s) == 0 {
    return ""
  } else {
    return string(s[len(s)-1]) + InvertiStringa(s[:len(s)-1])
  }
}
