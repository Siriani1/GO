package main

import "fmt"

func main() {

  var n int
  fmt.Scan(&n)

  sl1 := LeggiNumeri(n)
  sl2 := LeggiNumeri(n)
  prodotto := Moltiplica(sl1,sl2)
  fmt.Printf("Prodotto: %d, SIUM", prodotto)
}

func LeggiNumeri(n int) (sequenza []int) {
	if n == 0 {
		return
	} else {
		var valore int
		fmt.Scan(&valore)
		return append([]int{valore}, LeggiNumeri(n-1)...)
	}
}

func Moltiplica(sl1, sl2 []int) (prodotto int) {

  if len(sl1) == 0 {
    return
  } else {
    return sl1[0] * sl2[0] + Moltiplica(sl1[1:], sl2[1:])
  }



}
