package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	LeggiEStampa(scanner)
}

func LeggiEStampa(scanner *bufio.Scanner) {

	if scanner.Scan() {
    if scanner.Text() != "" {
      s := scanner.Text()
      LeggiEStampa(scanner)
  		fmt.Println(InvertiStringa(s))
    }
	}

}

func InvertiStringa(s string) string {
  if len(s) == 0 {
    return ""
  } else {
    return string(s[len(s)-1]) + InvertiStringa(s[:len(s)-1])
  }
}
