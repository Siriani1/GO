package main

import "fmt"
import "os"
import "strconv"

func LeggiNumeri() (numeri []int) {

  for _, s := range os.Args[1:] {
    if n, err := strconv.Atoi(s); err == nil {
      numeri = append(numeri, n)
    }
  }
  return
}

func ValoreFrazione(sl []int) float64 {
  fmt.Println(sl)
  if len(sl) == 0 {
    return 0
  } else if len(sl) == 1 {
    return float64(sl[0])
  } else {
    return float64(sl[0]) + 1 / ValoreFrazione(sl[1:])
  }
}

func main() {
  fmt.Println(ValoreFrazione(LeggiNumeri()))
}
