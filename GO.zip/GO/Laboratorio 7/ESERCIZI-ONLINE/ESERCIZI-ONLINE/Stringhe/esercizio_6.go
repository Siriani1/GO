package main

import "fmt"
//import "strings"
import "bufio"
import "os"

func LeggiTesto() (testo string) {
  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		testo += scanner.Text() + "\n"
	}
	return
}

func TraduciTesto(s string) string {
  var x string
  for _, carattere := range(s) {
    switch carattere {
    case 'a', 'A':
      x += TraduciCarattere(carattere)
    case 'e', 'E':
      x += TraduciCarattere(carattere)
    case 'i', 'I':
      x += TraduciCarattere(carattere)
    case 'o', 'O':
      x += TraduciCarattere(carattere)
    case 'u', 'U':
      x += TraduciCarattere(carattere)
    default:
      x += string(carattere)
    }
  }
  return x
}

func TraduciCarattere(c rune) (s string) {
  if 65 <= c && c < 86 {
    s = string(c)+"F"+string(c)
  }else{
    s = string(c)+"f"+string(c)
  }
  return
}


func main() {

  testo := LeggiTesto()
  newTesto := TraduciTesto(testo)

  fmt.Println(newTesto)
}
