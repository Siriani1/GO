package main

import "fmt"
import "bufio"
import "os"
import "strings"

func LeggiTesto() (testo string){

  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
    if scanner.Text() != ""{
        riga := scanner.Text()
        testo += riga + "\n"
        if testo == "" {
            continue
        }
    }else{
      break
    }
	}
	return testo[:len(testo)-1]

}

func TrasformaCarattere(r rune) rune {
  if strings.ContainsRune("aeiouAEIOU", r) {
    r = 'u'
  }
  return r
}

func Garibaldi(s string) (testo string) {

  for _, c := range(s) {
    c = TrasformaCarattere(c)
    testo += string(c)
  }
  return

}

func main() {
  s := LeggiTesto()
  fmt.Print(Garibaldi(s))
}
