package main

import (
	"bufio"
	"fmt"
	"os"
  //"strings"
	//"unicode"
)

func LeggiTesto() (testo string){

  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
    if scanner.Text() != ""{
        riga := scanner.Text()
        testo += riga + "\n"
        if testo == "" {
            continue
        }
    }else{
      break
    }
	}
	return testo[:len(testo)-1]

}

func Inverti_stringa(s string) (contrario string) {

  for i := len(s)- 1; i >= 0; i-- {
    fmt.Println(len(s))
    contrario = contrario + string(s[i])
  }

  return
}



func main() {

  testo := LeggiTesto()
  contrario := Inverti_stringa(testo)

  fmt.Println(testo)
  fmt.Println(contrario)

}
