package main

import "fmt"
import "unicode"
import "bufio"
import "os"

func LeggiTesto() (testo string) {
  scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		testo += scanner.Text() + "\n"
	}
	return
}

func Spazia(s string) (testo string) {
  testo += string(s[0])
  for i := 1; i < len(s); i++ {
    if !unicode.IsSpace(rune(s[i])) && !unicode.IsSpace(rune(s[i-1])){
      testo += " "
      testo += string(s[i])
    }else{
      testo += string(s[i])
    }
  }

  return
}

func main() {
  testo := LeggiTesto()
  fmt.Println(Spazia(testo))
}
