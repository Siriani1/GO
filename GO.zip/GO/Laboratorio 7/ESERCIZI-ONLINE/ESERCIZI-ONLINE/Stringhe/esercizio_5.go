package main

import "fmt"
import "unicode"
import "strconv"
import "bufio"
import "os"

func LeggiTesto() (testo string) {
  
  scanner := bufio.NewScanner(os.Stdin)
	if scanner.Scan() {
		testo = scanner.Text()
  }

  return
}

func NumeroNascosto(s string) (int, error) {
  var n string
  for _, carattere := range(s) {
    //fmt.Println(string(carattere))
    if unicode.IsDigit(carattere){
      n = n + string(carattere)
    }
  }
  //fmt.Println(lunghezza)
  return strconv.Atoi(n)
}

func main() {

  testo := LeggiTesto()

  numero, _ := NumeroNascosto(testo)

  fmt.Println("Il Doppio del numero:", numero, "è:", numero * 2)


}
