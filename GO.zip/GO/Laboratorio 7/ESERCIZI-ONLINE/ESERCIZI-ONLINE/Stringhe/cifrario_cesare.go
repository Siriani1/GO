package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"unicode"
)

// ReadNumber reads an integer from standard input and returns its value
func ReadNumber() int {
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	num, _ := strconv.Atoi(scanner.Text())
	return num
}

// ReadText reads a multi-line text from standard input and terminated by the EOF indicator,
// returning a string value in which the read text is stored
func ReadText() string {
	scanner := bufio.NewScanner(os.Stdin)
	var s string
	for scanner.Scan() {
		s += scanner.Text() + "\n"
	}
	return s
}

// DigitCharacter receives as input a rune value in the parameter c and an int value in the key parameter,
// and returns a rune value equal to c in case c is not a letter of the English alphabet,
// equal to the cipher value corresponding to c (obtained with encryption key key) otherwise.
// In particular, the encrypted value must be lowercase if c is lowercase and uppercase if c is uppercase.
func DigitCharacter(c rune, key int) rune {
	if !unicode.IsLetter(c) {
		return c
	}
	base := 'a'
	if unicode.IsUpper(c) {
		base = 'A'
	}
	return rune((int(c)-int(base)+key)%26 + int(base))
}

// EncryptText receives as input a string value in the parameter s and an int value in the key parameter,
// and returns a string value obtained encrypting each character of s with the DigitCharacter() function
func EncryptText(s string, key int) string {
	var encrypted string
	for _, c := range s {
		encrypted += string(DigitCharacter(c, key))
	}
	return encrypted
}

func main() {
	// Read the encryption key
	fmt.Print("Enter the encryption key: ")
	key := ReadNumber()

	// Read the clear message
	fmt.Println("Enter the clear message: ")
	message := ReadText()

	// Print the encrypted message
	fmt.Println("The encrypted message is:")
	fmt.Println(EncryptText(message, key))
}
