package main

import "fmt"
import "math/rand"
import "time"

func main() {
  rand.Seed(int64(time.Now().Nanosecond()))
  var n, turni, k int
  var giocatori, Vincitore []string
  var somma int

  fmt.Println("Numero giocatori partecipanti:")
  fmt.Scan(&n)

  giocatori = make([]string, n)
  fmt.Println("Inserisci nome dei giocatori:")
  for i := 0; i < n; i++ {
    fmt.Scan(&giocatori[i])

  }

  fmt.Println("Inserire numero turni:")
  fmt.Scan(&turni)

  Vincitore = make([]string, turni)


  for i := 0; i < turni; i ++ {
    fmt.Println("Turno", i+1)
    max := 0
    l := 0
    for j := range giocatori {
      dado1 := rand.Intn(7 - 1) + 1 // (max + 1 - min) - min
      dado2 := rand.Intn(7 - 1) + 1
      somma = dado1 + dado2
      //fmt.Print(somma)
      fmt.Println("Giocatore", giocatori[j], "lanci di valore:", dado1, "e", dado2)
      max, k = Vincente(somma, j, max, l)
      l = k
      //fmt.Println(max, k)
    }
    Vincitore[i] = giocatori[k]
    fmt.Println("Vincitore", Vincitore[i])
  }

  fmt.Println("Vittorie:")
  for i := 0; i < turni; i++ {
    fmt.Println("Vincente turno", i+1, ":", Vincitore[i])
  }

}


func Vincente (somma int, j int, max int, l int) (Max int, h int){
  Max = max
  h = l
  if somma > max {
    Max = somma
    h = j
  }

  return
}
