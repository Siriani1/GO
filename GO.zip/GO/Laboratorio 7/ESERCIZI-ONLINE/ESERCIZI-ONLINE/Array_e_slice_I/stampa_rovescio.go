package main

import "fmt"

func main() {
  var n int
  var numeri []int
  fmt.Scan(&n)
  numeri = make([]int, n)
  fmt.Println("Inserisci", n, "numeri")

  for i := 0; i < len(numeri); i++{
    fmt.Scan(&numeri[i])
  }

  for i := len(numeri) - 1; i >= 0; i-- {
    fmt.Print(numeri[i])
  }
}
