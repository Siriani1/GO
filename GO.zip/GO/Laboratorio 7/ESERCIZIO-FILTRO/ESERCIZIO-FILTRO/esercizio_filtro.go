package main

import "fmt"
import "strconv"


func main() {
  var numero int
  var s string

  //fmt.Println("Inserisci un numero")
  fmt.Scan(&numero)

  s = strconv.Itoa(numero)
  fmt.Printf("Output: %c", s[0])

  for i := 1; i < len(s); i++{
    if s[i] != s[i-1]{
      fmt.Printf("%c", s[i])
    }
  }



}
