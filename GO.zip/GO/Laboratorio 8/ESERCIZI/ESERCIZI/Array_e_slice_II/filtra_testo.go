package main

import "fmt"
import "bufio"
import "os"
import "unicode"

func LeggiTesto() (s []string) {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		s = append(s, scanner.Text() + "\n")
	}
	return
}

func ContieneCifre(s string) bool {
  for _, c := range s {
    if unicode.IsDigit(c) {
      return true
    }
  }
  return false
}

func FiltraTesto(sl []string) (testo []string) {
  for i := 0; i < len(sl); i++ {
    if ContieneCifre(sl[i]) {
      testo = append(testo, sl[i])
    }
  }
  return
}

func main() {
  fmt.Println(FiltraTesto(LeggiTesto()))
}
