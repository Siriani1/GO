package main

import "fmt"
import "bufio"
import "os"
import "sort"

func LeggiTesto() (date []string) {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		riga := scanner.Text()
		if riga != "" {
			date = append(date, riga)
		} else {
      break
    }
	}
	return
}

/**/

func Formatta(data string) string {
	dataRune := []rune(data)

	if len(dataRune) == 8 {
		dataRune = append(dataRune[:4], '-', '0', dataRune[5], '-', '0', dataRune[7])
	} else if len(dataRune) == 9 {
		if dataRune[6] == '/' {
			dataRune = append(dataRune[:4], '-', '0', dataRune[5], '-', dataRune[7], dataRune[8])
		} else {
			dataRune = append(dataRune[:4], '-', dataRune[5], dataRune[6], '-', '0', dataRune[8])
		}
	} else {
		dataRune[4] = '-'
		dataRune[7] = '-'
	}

	return string(dataRune)
}

func daInvertire(data string) bool{
  if data[1] == '/' || data[2] == '/' {
    return true
  }
  return false
}

func Inverti(data string) string {
  //dataRune := []rune(data)

	if len(data) == 8 {
		data = data[4:] + "/" + data[2:3] + "/" + data[0:1]
	} else if len(data) == 9 {
    if rune(data[1]) == '/' {
      data = data[5:] + "/" + data[3:4] + "/" + data[:1]
    } else {
      data = data[5:] + "/" + data[3:4] + "/" + data[:2]
    }
  } else {
    data = data[6:] + "/" + data[3:5] + "/" + data[:2]
  }
  return data
}

func main() {
	date := LeggiTesto()
  var gg []string
	for _, data := range date {
    if daInvertire(data) {
      data = Inverti(data)
    }
		gg = append(gg, Formatta(data))
	}
  
  sort.Strings(gg)

  for i := 0; i < len(gg); i++ {
    fmt.Println(gg[i])
  }

}
