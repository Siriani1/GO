package main

import "fmt"
import "os"
import "strconv"

func LeggiNumeri() (numeri []int) {

  for _, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
			numeri = append(numeri, n)
		}
	}
  return
}

func Occorrenze(numeri []int, n int) int {
  contatore := 0
  for i := range numeri {
    if numeri[i] == n {
      contatore ++
    }
  }

  return contatore

}


func main() {
  var somma int
  numeri := LeggiNumeri()

  for _,n := range numeri {
    if Occorrenze(numeri, n) == 1 {
      somma += n
    }
  }
  fmt.Println(somma)
}
