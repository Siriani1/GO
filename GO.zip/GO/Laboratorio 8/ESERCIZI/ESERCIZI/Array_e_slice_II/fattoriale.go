package main

import "fmt"
import "os"
import "strconv"

func Fattoriali(n int) (f []int) {
  for i := 1; i <= n; i++ {
    fattoriale := 1
    for j := 1; j <= i; j++ {
      fattoriale *= j
    }
    f = append(f, fattoriale)
  }

  return
}


func main() {
  for _, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
      fmt.Println(n)
			fmt.Println(Fattoriali(n))
		}
	}

}
