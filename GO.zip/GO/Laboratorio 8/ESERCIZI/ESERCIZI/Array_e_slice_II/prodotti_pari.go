package main

import "fmt"
import "os"
import "strconv"

func Calcola(sl []int) (somma int) {
  for i := 0; i < len(sl); i++ {
    //fmt.Println(sl[i])
    for j := i; j < len(sl); j++ {
      prodotto := 1
      if j != i {
        prodotto = sl[i] * sl[j]
        fmt.Println(prodotto)
      }
      if prodotto % 2 == 0 {
        somma += prodotto
      }
    }

  }

  return
}

func main() {

  var numeri []int
  numeri = make([]int, len(os.Args)-1)
  for i, v := range os.Args[1:] {

		if n, err := strconv.Atoi(v); err == nil {
			numeri[i] += n
		}
	}

  fmt.Println("La somma è:", Calcola(numeri))
}
