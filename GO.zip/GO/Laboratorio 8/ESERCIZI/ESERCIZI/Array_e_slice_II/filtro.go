package main

import "fmt"
import "os"
import "strconv"

func LeggiNumeri() (numeri []int) {

  numeri = make([]int, len(os.Args)-1)
  for i, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
			numeri[i] += n
		}
	}
  return numeri
}

func Filtravoti(sl []int) (sufficienti, insufficienti []int) {
  for i := 0; i < len(sl); i++ {
    if sl[i] > 60 {
      sufficienti = append(sufficienti, sl[i])
    } else {
      insufficienti = append(insufficienti, sl[i])
    }
  }

  return
}

func main() {
  suf, insuf := Filtravoti(LeggiNumeri())

  fmt.Println("I voti sufficienti:", suf)
  fmt.Println("I voti insufficienti:", insuf)
}
