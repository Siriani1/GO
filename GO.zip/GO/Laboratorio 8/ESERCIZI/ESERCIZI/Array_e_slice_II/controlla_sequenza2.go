package main

import "fmt"
import "os"
import "strconv"

func Valida(numeri []int) bool {
  var controllo bool
  for i := len(numeri) - 1; i > 1; i-- {
    if i % 2 == 0 {
      if numeri[i] > numeri[i-1] {
        controllo = true
      } else {
        fmt.Println("Valore in posizione", i, "non valido")
        return false
      }
    } else {
      if numeri[i] < numeri[i-1] {
        controllo = true
      } else {
        fmt.Println("Valore in posizione", i, "non valido")
        return false
      }
    }
  }

  return controllo
}

func main() {

  var numeri []int
  numeri = make([]int, len(os.Args)-1)
  for i, v := range os.Args[1:] {

    if n, err := strconv.Atoi(v); err == nil {
      numeri[i] += n
    }
  }

  if Valida(numeri) {
    fmt.Println("Sequenza Valida")
  }




}
