package main

import "fmt"
import "os"
import "strconv"

func LeggiNumeri() (numeri []int) {

  numeri = make([]int, len(os.Args)-1)
  for i, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
			numeri[i] += n
		}
	}
  return
}

func DivisoriPropri(n int) (divisori []int) {
  for i := 1; i < n; i++ {
    if n % i == 0 {
      divisori = append(divisori, i)
    }
  }

  return
}

func Controllo(div1 []int, div2 []int, divMin int, divMax int) (controllo1, controllo2 bool) {
  for i := 0; i < len(div1); i ++ {
    for j := 0; j < len(div2); j++ {
      if div1[i] == div2[j] {
        if div1[i] >= divMin || div2[j] >= divMin {
          controllo1 = true
        }
        if div1[i] <= divMax || div2[j] <= divMax {
          controllo2 = true
        }
      }
    }
  }

  return
}

func NumeroPerfetto(n int) bool {
  var somma int
  for i := 1; i < n; i ++ {
    if n % i == 0 {
      somma += i
    }
  }
  if somma == n {
    return true
  }
  return false
}


func main() {
  numeri := LeggiNumeri()
  n := numeri[0]
  divMin := numeri[1]
  divMax := numeri[2]
  a := 1
  b := 1
  //fmt.Println(NumeroPerfetto(28))
  for i := 0; i <= n; i++ {
    controlloA, controlloB := false, false
    fmt.Println(a,b)
    controllo1, controllo2 := Controllo(DivisoriPropri(a), DivisoriPropri(b), divMin, divMax)
    if controllo1 == true && controllo2 == true {
      if NumeroPerfetto(a) {
        controlloA = true
        fmt.Println(a, b)
      }
      if NumeroPerfetto(b) {
        controlloB = true
        fmt.Println(a, b)
      }
      if controlloA == true && controlloB == true {
        if a < b {
          a++
        } else {
          b++
        }
      } else if controlloA == true {
        b++
      } else {
        a++
      }
    } else {
      a++
      b++
    }

  }

}
