package main

import "fmt"
import "os"
import "strconv"

func Calcola(sl []int) (somma int) {

  for i := 1; i < len(sl); i += 2 {
    somma += sl[i] * sl[i-1]
  }
  return
}


func main() {

  var numeri []int
  numeri = make([]int, len(os.Args)-1)
  for i, v := range os.Args[1:] {

		if n, err := strconv.Atoi(v); err == nil {
			numeri[i] += n
		}
	}

  fmt.Println("La somma è:", Calcola(numeri))

}
