package main

import "fmt"
import "os"
import "strconv"


func LeggiNumeri() (numeri []int){

  for _, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
			numeri = append(numeri, n)
		}
	}

  return
}

func Min(sl []int) (minimo int) {

  minimo = sl[0]
  for i := 1; i < len(sl); i++ {
    if sl[i] < minimo {
      minimo = sl[i]
    }
  }

  return minimo

}

func Max(sl []int) (massimo int) {

  massimo = sl[0]

  for i := 1; i < len(sl); i++ {
    if sl[i] > massimo {
      massimo = sl[i]
    }
  }

  return
}

func Media(sl []int) (media float64) {
  var i int

  for i = 0; i < len(sl); i ++{
    media += float64(sl[i])
  }
  media /= float64(i)

  return
}


func main() {

  fmt.Println("Minimo", Min(LeggiNumeri()))
  fmt.Println("Massimo", Max(LeggiNumeri()))
  fmt.Println("Media", Media(LeggiNumeri()))
}
