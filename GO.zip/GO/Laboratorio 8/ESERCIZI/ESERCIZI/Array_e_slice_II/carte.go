package main

import "fmt"
import "os"
import "strconv"

func LeggiNumero() int {
  for _, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
      return n
		}
	}
  return 0
}



func main() {
  fmt.Print(LeggiNumero())
}
