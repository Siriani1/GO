package main

import "fmt"
import "os"
import "strconv"
import "math/rand"
import "time"

func LeggiNumeri() (numeri int) {

  for _, v := range os.Args[1:] {
		if n, err := strconv.Atoi(v); err == nil {
			numeri += n
		}
	}
  return
}

func Genera(soglia int) (numeri []int) {
  rand.Seed(int64(time.Now().Nanosecond()))
  numeroGenerato := rand.Intn(100)

  for numeroGenerato >= soglia {
    numeri = append(numeri, numeroGenerato)
    numeroGenerato = rand.Intn(100)
  }

  numeri = append(numeri, numeroGenerato)

  return
}

func main() {

  numeri := Genera(LeggiNumeri())

  fmt.Println("Valori generati:", numeri)
  fmt.Println("Valori sopra soglia", numeri[:len(numeri)-1])

}
