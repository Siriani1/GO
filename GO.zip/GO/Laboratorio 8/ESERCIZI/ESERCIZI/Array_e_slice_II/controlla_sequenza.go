package main

import "fmt"
import "unicode"
import "strconv"

func IsSpace(r rune) bool {
  if !unicode.IsSpace(r) {
    return false
  }

  return true
}

func Decrescente(numeri []int) bool{
  for i := 1; i < len(numeri); i++ {
    if numeri[i] > numeri[i-1] {
      return false
    }
  }

  return true
}

func main() {

  var s string
  var numeri []int

  fmt.Println("Inserisci testo")
  fmt.Scan(&s)

  for _,c := range s {
    if IsSpace(c) {
      fmt.Println("Nella stringa c'è della spaziatura. Ciao")
      return
    }

    if unicode.IsDigit(c) {
      n, _ := strconv.Atoi(string(c))
      numeri = append(numeri, n)
    }
  }

  if Decrescente(numeri) {
    fmt.Println("Sequenza nascosta ordinata")
    fmt.Println(numeri)
  } else {
    fmt.Println("Sequenza nascosta non ordinata")
    fmt.Println(numeri)
  }



}
