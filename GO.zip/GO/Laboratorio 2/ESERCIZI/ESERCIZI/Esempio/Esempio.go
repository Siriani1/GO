package main

import "fmt"

func main() {
fmt.Println("Esempio)
var A it = 10
fmt.Println("Il valore della variabile è:",A)
A = 12.5
fmt.Println("Il nuovo valore della variabile è:",A)
}