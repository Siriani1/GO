package main

import "fmt"

func main() {

	var a, b int

	fmt.Scan(&a, &b)

	var r int 
	r = a - b

	fmt.Println(r)

}
