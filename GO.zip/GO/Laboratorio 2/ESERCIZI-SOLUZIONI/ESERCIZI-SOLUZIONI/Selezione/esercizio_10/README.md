# Divisione

Scrivere un programma che legga da **standard input** due numeri interi `a` e `b` e calcoli il risultato della divisione `a/b`.
Se `b` è uguale a 0, il programma stampa `Impossibile`.

##### Esempio d'esecuzione:

```text
$ go run divisione.go
Inserisci due numeri:
5 2
Quoziente = 2.5

$ go run divisione.go
Inserisci due numeri:
5 0
Impossibile
```
