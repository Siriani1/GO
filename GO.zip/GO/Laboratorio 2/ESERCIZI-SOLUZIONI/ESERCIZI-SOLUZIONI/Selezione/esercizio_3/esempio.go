package main

import "fmt"

func main() {

	var a, b int = 10, 10

	if a <= b {

		fmt.Println("a <= b")

	} else {

		fmt.Println("a > b")

	}

}
