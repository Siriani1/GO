package main

import "fmt"

func main() {

	var a, b int

	fmt.Scan(&a, &b)

	r := a - b

	fmt.Println(r)

}
