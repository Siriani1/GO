package main

import "fmt"

func main() {
	var a
	a = 10

	var b, d int
	b = 20

	c = 30
	var c int

	var d int = a + b + c

	fmt.Println((d)
}
