# Trova l'errore

Questo programma dovrebbe stampare la somma di tre numeri interi `a`, `b` e `c`, ma contiene degli errori.
Corregere gli errori e verificare che l'esecuzione produca l'output desiderato.

```go
package main

import "fmt"

func main() {
	var a
	a = 10
	
	var b, d int
	b = 20
	
	c = 30
	var c int

	var d int = a + b + c
	
	fmt.Println((d)
}
```
