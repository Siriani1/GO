# Convertitore Km - miglia

Scrivere un programma che legga da **standard input** una distanza in Km ed effettui la conversione di tale distanza in miglia (1 Km = 0.62137 mi).

##### Esempio d'esecuzione:

```text
$ go run convertitore.go
Distanza (Km) = 12
Distanza (mi) = 7.45644
```
