package main

import "fmt"

func main() {
	var a int = 10
	var b int = 20
	a = a + b
	var c int = a + b
	fmt.Println(c)
}
