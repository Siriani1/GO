package main

import "fmt"

func main() {
	var a int = 5
	var b float64 = 3.14

	fmt.Print("Valore di a:", a, "capito? Te lo dico due volte:", a, a, "...\n")
	fmt.Print("Valore di b:", b, b, "\n")
}
