package main

import "fmt"

func main() {
	var a int = 5
	var b float64 = 3.14

	fmt.Println("Valore di a:", a, "capito? Te lo dico due volte:", a, a, "...")
	fmt.Println("Valore di b:", b, b)
}
