# Area e perimetro rettangolo

Scrivere un programma che legga da **standard input** le misure dell’altezza e della base di un rettangolo e ne calcoli il perimetro e l’area.

##### Esempio d'esecuzione:

```text
$ go run rettangolo.go
Inserisci la base: 20
Inserisci l'altezza: 10
Perimetro = 60
Area = 200
```
