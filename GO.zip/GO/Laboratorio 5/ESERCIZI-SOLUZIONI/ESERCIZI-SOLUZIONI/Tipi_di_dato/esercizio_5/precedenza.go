package main

import "fmt"

func main() {
	var a, b, c int = 10, 5, 4
	fmt.Println(a / b * c)
}
