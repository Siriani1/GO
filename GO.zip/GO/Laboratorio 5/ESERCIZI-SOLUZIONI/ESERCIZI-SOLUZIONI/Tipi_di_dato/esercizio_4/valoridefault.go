package main

import "fmt"

func main() {

	var numeroIntero int
	var numeroReale float64
	var valoreLogico bool

	fmt.Print("Valore di default per il tipo int: _", numeroIntero, "_\n")
	fmt.Print("Valore di default per il tipo float64: _", numeroReale, "_\n")
	fmt.Print("Valore di default per il tipo bool: _", valoreLogico, "_\n")

}