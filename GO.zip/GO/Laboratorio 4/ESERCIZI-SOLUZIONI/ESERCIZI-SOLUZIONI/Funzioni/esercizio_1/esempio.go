package main

import "fmt"

func funzione() {
	fmt.Println("Hello world!")
}

func main() {
	funzione()
}
