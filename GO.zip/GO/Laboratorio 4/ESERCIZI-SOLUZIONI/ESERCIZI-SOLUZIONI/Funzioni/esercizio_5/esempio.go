package main

import "fmt"

func test(x int) y int, z int
{
var y int = x + 1
var z int = x + 2
return
}

func main() {
	var a, b int
	a, b = test(10)
	fmt.Println(a, b)
}
