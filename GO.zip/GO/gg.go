package main

import "fmt"
import "strings"

func main() {

	fmt.Println(strings.Count("cheese", "e"))
	fmt.Printf("%9.f Ciao", 34.65647474764)
}
