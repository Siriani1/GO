package main

import "fmt"
import "math"
import "strconv"

func ConvertitoreBtoInt(numero string, b int)   {
  var somma, operazione float64
  var x int
  var s string
  for i := 0; i < len(numero); i++{
    if i < 1 {
      x = len(numero)-1
      s = numero[x:x+1]
    }else{
      x = len(numero) - (i + 1)
      s = numero[x:x+1]
    }

    a , _ := strconv.ParseFloat(s,64)
    //fmt.Println(a)
    operazione = a * math.Pow(float64(b), float64(i))
    //fmt.Println("operazione", math.Pow(float64(b), float64(i)))
    somma += operazione
    //fmt.Println("somma",somma)
  }
  fmt.Println(somma)
}

func ConvertitoreIntToB(numero int, b int) {
  var n string

  for {
    var div int
    div = numero % b
    //fmt.Println(div)
    numero = numero / b
    //fmt.Println(numero)
    n = strconv.Itoa(div) + n
    if numero < b {
      var div int
      div = numero
      //fmt.Println(div)
      n = strconv.Itoa(div) + n
      break
    }
  }
  fmt.Println(n)

}

func main() {
    var numero, b, valore int
    var n string

    //b = len(numero) - 2

    //numero = numero[b: b+1]


    for valore != 3 {
      fmt.Println("Inserisci la scelta")
      fmt.Scan(&valore)
      switch valore {
      case 1:
        fmt.Println("Inserisci numero e base:")
        fmt.Scan(&n, &b)
        ConvertitoreBtoInt(n, b)
      case 2:
        fmt.Println("Inserisci numero e base:")
        fmt.Scan(&numero, &b)
        ConvertitoreIntToB(numero, b)
      case 3:
        break
      }
    }

    fmt.Println("ciao")

}
