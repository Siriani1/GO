package main

import "fmt"

// Valore/Codice unicode che corrisponde all'asso di cuori
const ACE = '\U0001F0B1'

// Valore/Codice unicode che corrisponde al 10 di cuori, ovvero il codice dell'asso + 9
const TEN = '\U0001F0B1' + 9
	
func main() {

	// Per tutti i valori/codici compresi tra l'asso e il 10, stampa il carattere corrispondente e il valore/codice numerico
	// I codici tra ACE e TEN sono i codici delle carte di cuori
	for c := ACE; c <= TEN; c++ {
		fmt.Println("Simbolo:", string(c), "- Valore/Codice numerico in base 10:", c)
	}

}
